$root = Split-Path -Parent $PSScriptRoot
$shortcutPath = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Codex Usage Widget.lnk'
$launcher = Join-Path $root 'Start-CodexUsageWidget.exe'
$icon = Join-Path $root 'app\CodexUsageWidget.ico'

$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $launcher
$shortcut.Arguments = ''
$shortcut.WorkingDirectory = (Join-Path $root 'app')
$shortcut.IconLocation = $icon + ',0'
$shortcut.Description = 'Show Codex usage remaining'
$shortcut.Save()
Write-Output "Created: $shortcutPath"
