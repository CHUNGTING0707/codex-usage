# Codex／Claude 剩餘用量小工具 安裝須知

這是一個 Windows 浮動式小工具，用來顯示已登入 ChatGPT 帳號的 Codex 剩餘用量，以及 Claude 的 5 小時／每週剩餘用量。

## 使用前請確認

- 使用 Windows 10 或 Windows 11。
- 已安裝 Codex Desktop。
- 使用的 ChatGPT 帳號具備 Codex 使用資格。

## 安裝與首次啟動

1. 將 ZIP 解壓縮到任意資料夾，請保留完整資料夾結構。
2. 進入 `setup` 資料夾，執行 `Connect-CodexAccount.cmd`。
3. 依瀏覽器開啟的官方裝置登入流程完成 ChatGPT 帳號授權。
4. 回到最外層資料夾，雙擊 `Start-CodexUsageWidget.exe` 開啟小工具。
5. 可選：執行 `setup/Install-DesktopShortcut.ps1`，建立含自訂圖示的桌面捷徑。

## 第一次登入遇到裝置授權限制時

若執行 `Connect-CodexAccount.cmd` 或 `codex login --device-auth` 時，畫面要求先啟用 Codex 裝置代碼授權，請依序操作：

1. 在 ChatGPT 開啟 **Settings** -> **Security／安全性設定**。
2. 啟用「**Codex 裝置代碼授權**」。
3. 回到終端重新執行：

   ```powershell
   codex login --device-auth
   ```

4. 依官方頁面完成一次性裝置代碼授權，並確認終端顯示 `Successfully logged in`。
5. 重新開啟 `Start-CodexUsageWidget.exe`。

提醒：Codex Desktop 已登入不一定會自動授權給命令列 App Server，因此第一次使用本小工具仍須完成上述 CLI 裝置授權。

## 使用方式

- 拖曳卡片可移動位置。
- 按 `Refresh` 可立即更新用量；否則每兩分鐘自動更新一次。
- 按右上角 `X` 可關閉小工具。

## Claude 用量設定（可選）

小工具下半部顯示 Claude 用量。要顯示和 Claude「設定 → 用量」頁面一致的官方剩餘 %，請在這台電腦安裝並登入一次 Claude Code 命令列工具：

1. 在 PowerShell 執行 `irm https://claude.ai/install.ps1 | iex`（只開一個視窗執行，等它跑完）。
2. 執行 `& "$env:USERPROFILE\.local\bin\claude.exe"`，選擇用 Claude 訂閱帳號登入，在瀏覽器授權後輸入 `/exit` 離開。
3. 重新開啟 `Start-CodexUsageWidget.exe`。

- 登入 token 大約 8 小時過期一次。過期時小工具會在背景呼叫 Claude Code 命令列工具，送出一個只回「ok」的 Haiku 請求，讓它自動換新登入（會用掉極少量額度）；失敗時會稍後再重試（最長 4 小時），也可以執行一次 `claude` 立即恢復。
- 這個查詢方式不是 Anthropic 公開文件寫明的，之後可能會改變。
- 沒有登入或查詢失敗時，小工具會改用本機 Claude Code 對話紀錄估算用量，狀態列會以 `Estimate -` 開頭。這時可以按「校準」，輸入 Claude 用量頁面上的 %，讓估算值改以剩餘 % 顯示。
- 查詢有問題時，可查看 `app\ClaudeUsage.log`（每次查詢成功／失敗與原因，不含 token），或執行 `development\Test-ClaudeOfficialUsage.ps1` 診斷。

## 隱私與費用

本工具只透過本機 Codex App Server 讀取 Codex 用量資料，不會送出模型提示、不需要 API Key，也不會消耗 Codex 額度。

Claude 用量查詢本身不會傳送提示詞，也不會消耗 Claude 額度；只有約每 8 小時換新登入時，會透過 Claude Code 送出一個極小的 Haiku 請求。登入資訊只保存在本機的 `%USERPROFILE%\.claude\.credentials.json`，不會被打包或上傳。
