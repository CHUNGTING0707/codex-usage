# Codex 剩餘用量小工具 安裝須知

這是一個 Windows 浮動式小工具，用來顯示已登入 ChatGPT 帳號的 Codex 剩餘用量。

## 使用前請確認

- 使用 Windows 10 或 Windows 11。
- 已安裝 Codex Desktop。
- 使用的 ChatGPT 帳號具備 Codex 使用資格。

## 安裝與首次啟動

1. 將 ZIP 解壓縮到任意資料夾，請保留完整資料夾結構。
2. 進入 `setup` 資料夾，執行 `Connect-CodexAccount.cmd`。
3. 依瀏覽器開啟的官方裝置登入流程完成 ChatGPT 帳號授權。
4. 回到最外層資料夾，雙擊 `Start-CodexUsageWidget.exe` 開啟小工具。
5. 可選：執行 `setup/Install-DesktopShortcut.ps1`，建立含自訂圖示的桌面捷徑。

## 第一次登入遇到裝置授權限制時

若執行 `Connect-CodexAccount.cmd` 或 `codex login --device-auth` 時，畫面要求先啟用 Codex 裝置代碼授權，請依序操作：

1. 在 ChatGPT 開啟 **Settings** -> **Security／安全性設定**。
2. 啟用「**Codex 裝置代碼授權**」。
3. 回到終端重新執行：

   ```powershell
   codex login --device-auth
   ```

4. 依官方頁面完成一次性裝置代碼授權，並確認終端顯示 `Successfully logged in`。
5. 重新開啟 `Start-CodexUsageWidget.exe`。

提醒：Codex Desktop 已登入不一定會自動授權給命令列 App Server，因此第一次使用本小工具仍須完成上述 CLI 裝置授權。

## 使用方式

- 拖曳卡片可移動位置。
- 按 `Refresh` 可立即更新用量；否則每兩分鐘自動更新一次。
- 按右上角 `X` 可關閉小工具。

## 隱私與費用

本工具只透過本機 Codex App Server 讀取用量資料，不會送出模型提示、不需要 API Key，也不會消耗 Codex 額度。
