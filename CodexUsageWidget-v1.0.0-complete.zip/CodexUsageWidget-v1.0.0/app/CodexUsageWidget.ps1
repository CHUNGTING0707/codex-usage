<#
  Codex Usage Widget
  A local, always-on-top WPF display for the authenticated Codex rate limits.
  It uses `codex app-server` and only calls account/rateLimits/read.
#>

[CmdletBinding()]
param(
    [ValidateRange(30, 3600)]
    [int]$RefreshSeconds = 120
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase

$script:AppServer = $null
$script:RequestId = 0

function Get-CodexCommand {
    $desktopBin = Join-Path $env:LOCALAPPDATA 'OpenAI\Codex\bin'
    $desktopCli = @(Get-ChildItem -Path $desktopBin -Directory -ErrorAction SilentlyContinue |
        ForEach-Object {
            $candidate = Join-Path $_.FullName 'codex.exe'
            if (Test-Path $candidate) { Get-Item $candidate }
        } |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1)
    if ($desktopCli.Count -gt 0) { return $desktopCli[0].FullName }

    $command = Get-Command codex -ErrorAction SilentlyContinue
    if (-not $command) {
        throw 'Codex command line tool was not found. Start or install Codex Desktop first.'
    }
    return $command.Source
}

function Send-RpcMessage([hashtable]$Message) {
    $json = $Message | ConvertTo-Json -Depth 12 -Compress
    $script:AppServer.StandardInput.WriteLine($json)
    $script:AppServer.StandardInput.Flush()
}

function Read-RpcResponse([int]$ExpectedId, [int]$TimeoutMs = 10000) {
    $deadline = [DateTime]::UtcNow.AddMilliseconds($TimeoutMs)
    while ([DateTime]::UtcNow -lt $deadline) {
        $remaining = [Math]::Max(1, [int]($deadline - [DateTime]::UtcNow).TotalMilliseconds)
        $task = $script:AppServer.StandardOutput.ReadLineAsync()
        if (-not $task.Wait($remaining)) { break }
        $line = $task.Result
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        try { $message = $line | ConvertFrom-Json } catch { continue }
        # Notifications such as account/rateLimits/updated have no JSON-RPC id.
        # Ignore them here; this function waits only for the matching response.
        $responseId = $message.PSObject.Properties['id']
        if ($null -ne $responseId -and [int]$responseId.Value -eq $ExpectedId) {
            $responseError = $message.PSObject.Properties['error']
            if ($null -ne $responseError) {
                throw ("Codex App Server error: {0}" -f ($responseError.Value | ConvertTo-Json -Compress))
            }
            $responseResult = $message.PSObject.Properties['result']
            if ($null -eq $responseResult) { throw 'Codex App Server returned a response with no result.' }
            return $responseResult.Value
        }
    }
    throw 'Timed out waiting for Codex App Server. Confirm that Codex Desktop is signed in.'
}

function Start-AppServer {
    if ($script:AppServer -and -not $script:AppServer.HasExited) { return }

    $psi = [System.Diagnostics.ProcessStartInfo]::new()
    $psi.FileName = Get-CodexCommand
    $psi.Arguments = 'app-server --stdio'
    $psi.UseShellExecute = $false
    $psi.RedirectStandardInput = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.CreateNoWindow = $true

    $script:AppServer = [System.Diagnostics.Process]::new()
    $script:AppServer.StartInfo = $psi
    if (-not $script:AppServer.Start()) { throw 'Could not start Codex App Server.' }

    $script:RequestId = 1
    Send-RpcMessage @{ method = 'initialize'; id = $script:RequestId; params = @{ clientInfo = @{ name = 'codex_usage_widget'; title = 'Codex Usage Widget'; version = '1.0.0' } } }
    [void](Read-RpcResponse -ExpectedId $script:RequestId)
    Send-RpcMessage @{ method = 'initialized'; params = @{} }
}

function Get-UsageLimits {
    Start-AppServer
    $script:RequestId++
    Send-RpcMessage @{ method = 'account/rateLimits/read'; id = $script:RequestId; params = @{} }
    return Read-RpcResponse -ExpectedId $script:RequestId
}

function Get-RemainingText($Window) {
    if ($null -eq $Window) { return '-' }
    $left = [Math]::Max(0, 100 - [double]$Window.usedPercent)
    return ('{0:0}%' -f $left)
}

function Get-ResetText($Window) {
    if ($null -eq $Window -or $null -eq $Window.resetsAt) { return 'Reset time unavailable' }
    $reset = [DateTimeOffset]::FromUnixTimeSeconds([int64]$Window.resetsAt).ToLocalTime()
    $span = $reset - [DateTimeOffset]::Now
    if ($span.TotalSeconds -le 0) { return 'Resetting now' }
    if ($span.TotalDays -ge 1) { return ('Resets in {0}d {1}h' -f [Math]::Floor($span.TotalDays), $span.Hours) }
    return ('Resets in {0}h {1}m' -f $span.Hours, $span.Minutes)
}

[xml]$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Codex Usage" Width="360" Height="220" WindowStartupLocation="Manual"
        Left="1200" Top="700" Topmost="True" ResizeMode="NoResize" ShowInTaskbar="True"
        Background="Transparent" AllowsTransparency="True" WindowStyle="None">
  <Border Name="Card" CornerRadius="20" BorderThickness="1" BorderBrush="#5E78A0"
          Background="#EB111A2A" Padding="22">
    <Grid>
      <Grid.RowDefinitions>
        <RowDefinition Height="Auto"/><RowDefinition Height="20"/><RowDefinition Height="Auto"/>
        <RowDefinition Height="18"/><RowDefinition Height="Auto"/><RowDefinition Height="20"/><RowDefinition Height="Auto"/>
      </Grid.RowDefinitions>
      <Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width="108"/></Grid.ColumnDefinitions>
      <TextBlock Grid.Row="0" Text="&#21097;&#39192;&#29992;&#37327;" Foreground="White" FontSize="24" FontWeight="SemiBold"/>
      <Button Name="CloseButton" Grid.Row="0" Grid.ColumnSpan="2" Content="X" FontSize="16" FontWeight="Light"
              Foreground="#D7E6FF" Background="Transparent" BorderThickness="0" Cursor="Hand"
              HorizontalAlignment="Right" VerticalAlignment="Top" Width="28" Height="28" Padding="0"/>
      <TextBlock Grid.Row="2" Text="5&#23567;&#26178;&#29992;&#37327;" Foreground="#D7E6FF" FontSize="14"/>
      <TextBlock Name="PrimaryText" Grid.Row="2" Grid.Column="1" Text="Loading..." Foreground="White" FontSize="14" HorizontalAlignment="Right"/>
      <ProgressBar Name="PrimaryBar" Grid.Row="3" Grid.ColumnSpan="2" Height="8" Minimum="0" Maximum="100" Value="0"
                   Foreground="#46DBCA" Background="#344155" BorderThickness="0"/>
      <TextBlock Grid.Row="4" Text="1&#36913;&#29992;&#37327;" Foreground="#D7E6FF" FontSize="14"/>
      <TextBlock Name="SecondaryText" Grid.Row="4" Grid.Column="1" Text="Loading..." Foreground="White" FontSize="14" HorizontalAlignment="Right"/>
      <ProgressBar Name="SecondaryBar" Grid.Row="5" Grid.ColumnSpan="2" Height="8" Minimum="0" Maximum="100" Value="0"
                   Foreground="#6F91FF" Background="#344155" BorderThickness="0"/>
      <Grid Grid.Row="6" Grid.ColumnSpan="2" Margin="0,12,0,0">
        <Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width="62"/></Grid.ColumnDefinitions>
        <TextBlock Name="StatusText" Text="Connecting to Codex..." Foreground="#9FB1CC" FontSize="12" VerticalAlignment="Center" TextTrimming="CharacterEllipsis"/>
        <Button Name="RefreshButton" Grid.Column="1" Content="Refresh" Foreground="#CFE5FF" Background="Transparent" BorderBrush="#58739A"
                BorderThickness="1" Height="20" FontSize="10" Padding="0" Cursor="Hand" HorizontalAlignment="Right" Width="58"/>
      </Grid>
    </Grid>
  </Border>
</Window>
'@

$reader = [System.Xml.XmlNodeReader]::new($xaml)
$window = [Windows.Markup.XamlReader]::Load($reader)
$iconPath = Join-Path $PSScriptRoot 'CodexUsageWidget.ico'
if (Test-Path $iconPath) {
    $window.Icon = [System.Windows.Media.Imaging.BitmapFrame]::Create([Uri]$iconPath)
}
$card = $window.FindName('Card')
$primaryText = $window.FindName('PrimaryText')
$secondaryText = $window.FindName('SecondaryText')
$primaryBar = $window.FindName('PrimaryBar')
$secondaryBar = $window.FindName('SecondaryBar')
$statusText = $window.FindName('StatusText')
$refreshButton = $window.FindName('RefreshButton')
$closeButton = $window.FindName('CloseButton')

$card.Add_MouseLeftButtonDown({ if ($_.ButtonState -eq 'Pressed') { $window.DragMove() } })
$closeButton.Add_Click({ $window.Close() })

$refreshUsage = {
    try {
        $statusText.Text = 'Updating...'
        $usage = Get-UsageLimits
        $limitGroups = $usage.PSObject.Properties['rateLimitsByLimitId']
        $limits = if ($null -ne $limitGroups -and $null -ne $limitGroups.Value.PSObject.Properties['codex']) {
            $limitGroups.Value.PSObject.Properties['codex'].Value
        } else {
            $usage.PSObject.Properties['rateLimits'].Value
        }
        $primary = $limits.PSObject.Properties['primary'].Value
        $secondaryProperty = $limits.PSObject.Properties['secondary']
        $secondary = if ($null -eq $secondaryProperty) { $null } else { $secondaryProperty.Value }
        $primaryText.Text = Get-RemainingText $primary
        $secondaryText.Text = Get-RemainingText $secondary
        $primaryBar.Value = [Math]::Max(0, 100 - [double]$primary.usedPercent)
        $secondaryBar.Value = if ($null -eq $secondary) { 0 } else { [Math]::Max(0, 100 - [double]$secondary.usedPercent) }
        $statusText.Text = Get-ResetText $primary
    }
    catch {
        $statusText.Text = $_.Exception.Message
        $statusText.TextWrapping = 'Wrap'
        $primaryText.Text = 'Unavailable'
        $secondaryText.Text = 'Unavailable'
    }
}

$refreshButton.Add_Click($refreshUsage)
$timer = [System.Windows.Threading.DispatcherTimer]::new()
$timer.Interval = [TimeSpan]::FromSeconds($RefreshSeconds)
$timer.Add_Tick($refreshUsage)
$timer.Start()
$window.Add_Closed({
    $timer.Stop()
    if ($script:AppServer -and -not $script:AppServer.HasExited) { $script:AppServer.Kill() }
})

$window.Show()
& $refreshUsage
[System.Windows.Threading.Dispatcher]::Run()
